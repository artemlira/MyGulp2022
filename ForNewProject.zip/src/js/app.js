import * as flsFunctions from "./modules/functions.js";
// import * as burgerMenu from "./modules/burger-menu.js";

flsFunctions.isWebp();
// burgerMenu.showMenu();

import Swiper, { Navigation, Pagination } from 'swiper';

const swiper = new Swiper();
